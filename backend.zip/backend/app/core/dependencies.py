# -*- coding: utf-8 -*-
"""
===============================================================================
DEPENDÊNCIAS DE AUTORIZAÇÃO (RBAC)
===============================================================================

Este módulo implementa o sistema de autorização baseado em papéis
(Role Based Access Control).

Ele funciona em conjunto com:

    core/security.py → autenticação JWT
    models/base_models.py → definição de User e Role

Responsabilidades deste arquivo:

• Verificar papéis do usuário logado
• Garantir acesso apenas a usuários autorizados
• Suportar modelo novo (N:N) e legado (role único)

===============================================================================
"""

# =============================================================================
# IMPORTS
# =============================================================================

from typing import Set
from fastapi import Depends, HTTPException, status

# Função que retorna o usuário autenticado via JWT
from app.core.security import get_current_user

# Modelo ORM do usuário
from app.models.base_models import User


# =============================================================================
# FUNÇÃO INTERNA
# =============================================================================

def _collect_user_role_names(user: User) -> Set[str]:
    """
    Coleta todos os papéis do usuário.

    Compatibilidade com dois modelos:

    MODELO NOVO (RECOMENDADO)
        user.roles -> relação N:N
        Ex:
            user.roles = [ADMIN, TEACHER]

    MODELO LEGADO
        user.role -> um único papel

    Retorna:
        Set[str] contendo nomes dos papéis
    """

    names: Set[str] = set()

    # -------------------------------------------------------------------------
    # MODELO NOVO (N:N)
    # -------------------------------------------------------------------------

    roles_attr = getattr(user, "roles", None)

    if roles_attr:
        for r in roles_attr:
            name = getattr(r, "name", None)

            if name:
                names.add(name)
            else:
                names.add(str(r))

    # -------------------------------------------------------------------------
    # FALLBACK LEGADO
    # -------------------------------------------------------------------------

    if not names:
        legacy = getattr(user, "role", None)

        if legacy:
            name = getattr(legacy, "name", None)

            if name:
                names.add(name)
            else:
                names.add(str(legacy))

    return names


# =============================================================================
# DEPENDÊNCIA PRINCIPAL
# =============================================================================

def require_role(*required_roles: str):
    """
    Dependência FastAPI que exige papéis específicos.

    Uso em rotas:

        @router.get("/admin")
        def admin_area(
            user = Depends(require_role("ADMIN"))
        ):

    Ou múltiplos papéis:

        Depends(require_role("ADMIN", "COORDINATOR"))

    O acesso será permitido se o usuário possuir
    pelo menos UM dos papéis exigidos.
    """

    if not required_roles:
        raise ValueError(
            "require_role precisa de pelo menos um papel (ex.: 'ADMIN')."
        )

    # -------------------------------------------------------------------------
    # FUNÇÃO INTERNA EXECUTADA PELO FASTAPI
    # -------------------------------------------------------------------------

    def checker(current_user: User = Depends(get_current_user)):

        user_roles = _collect_user_role_names(current_user)

        # verifica se existe interseção entre papéis exigidos e papéis do usuário
        if not any(role in user_roles for role in required_roles):

            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Você não tem permissão para acessar este recurso.",
            )

        return current_user

    return checker
