# -*- coding: utf-8 -*-
"""
===============================================================================
SHIM DE COMPATIBILIDADE
===============================================================================

Este arquivo existe apenas para manter compatibilidade com código antigo.

Algumas rotas antigas podem importar:

    from app.core.deps import require_role

Enquanto o código novo usa:

    from app.core.dependencies import require_role

Para evitar quebrar o sistema, este arquivo apenas REEXPORTA
as funções canônicas.

No futuro ele pode ser removido quando todos os imports forem
atualizados.

===============================================================================
"""

# Reexporta função de autenticação
from app.core.security import get_current_user  # noqa: F401

# Reexporta verificador de papéis
from app.core.dependencies import require_role  # noqa: F401


# Define exportação pública
__all__ = [
    "get_current_user",
    "require_role",
]
